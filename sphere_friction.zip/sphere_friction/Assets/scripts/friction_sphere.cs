﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;


public class friction_sphere : MonoBehaviour
{

    //the multiplier of the force of the movement
    [Range(0, 20)]
    public float constantforce = 4;
    //the multiplier for the force of the friction
    [Range(0, 1)]
    public float ForceMultiplier = 0.2f;
    //the rigidbody of the cube
    public Rigidbody myRB;
    //the mass of the sphere
    [Range(0, 5)]
    public float mass=1;
    //the point for the velocity
    Vector3 point;

    void Start()
    {
        //get the rigidbody of the sphere
        myRB = this.gameObject.GetComponent<Rigidbody>();
        //get the mass of the sphere with a coefficient
        mass = myRB.mass;
        //the point for the direction of the movement of the sphere
        point = new Vector3(2, 0, 0);
    }

    // Update is called once per frame
    void FixedUpdate()
    {
        if (constantforce > ForceMultiplier * mass * 9.8f)
        {
            //the velocity of the sphere
            myRB.velocity = point *( constantforce-ForceMultiplier* mass * 9.8f);

        }
        else
        {
            //the sphere stops
            myRB.velocity = Vector3.zero;
        }

    }
}
